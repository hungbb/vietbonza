var level1={
    obj:[
        {
            "top": -1, "left": -1, "bottom": -1, "right": 1, "value": "N","idx":0, "initX":50,"initY":50
        }, 
		{
			"top": -1, "left": -1, "bottom": -1, "right": 2, "value": "G", "idx":1
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": 3, "value": "S", "idx":2
		},
		{
			"top": -1, "left": -1, "bottom": 4, "right": -1, "value": "A", "idx":3
		},
		{
			"top": -1, "left": -1, "bottom": 5, "right": -1, "value": "N", "idx":4
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "H", "idx":5
		},
		
		{
            "top": -1, "left": -1, "bottom": 7, "right": -1, "value": "H","idx":6, "initX":0,"initY":450
        }, 
		{
			"top": -1, "left": -1, "bottom": 8, "right": -1, "value": "O", "idx":7
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "A", "idx":8
		},
		
		{
            "top": -1, "left": -1, "bottom": 10, "right": -1, "value": "K","idx":9, "initX":0,"initY":180
        }, 
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "H", "idx":10
		},
		
		
		{
            "top": -1, "left": -1, "bottom": 12, "right": -1, "value": "N","idx":11, "initX":180,"initY":500
        }, 
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "U", "idx":12
		},
		
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 14, "value": "B","idx":13, "initX":300,"initY":50
        }, 
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "I", "idx":14
		},
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 16, "value": "T","idx":15, "initX":50,"initY":300
        }, 
		{
			"top": -1, "left": -1, "bottom": -1, "right": 17, "value": "R", "idx":16
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": 18, "value": "U", "idx":17
		},
		{
			"top": -1, "left": -1, "bottom": 19, "right": -1, "value": "O", "idx":18
		},
		{
			"top": -1, "left": -1, "bottom": 20, "right": -1, "value": "C", "idx":19
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "Y", "idx":20
		},
		
		{
            "top": 22, "left": -1, "bottom": -1, "right": -1, "value": "N","idx":21, "initX":300,"initY":250
        }, 
		{
			"top": -1, "left": -1, "bottom": -1, "right": 23, "value": "E", "idx":22
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "N", "idx":23
		},
    ],
    answer:[
        {"isSolved":false,"value":[15,16,17,18,0,1,2,3],"text":"TRUONGSA"},
		{"isSolved":false,"value":[9,10,3,4,5,6,7,8],"text":"KHANHHOA"},
		
		{"isSolved":false,"value":[11,12,18,19,20,22,21],"text":"NUOCYEN"},
		{"isSolved":false,"value":[13,14,22,23],"text":"BIEN"},
		
		
		
    ]

}
