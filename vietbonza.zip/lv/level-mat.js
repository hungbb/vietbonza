var level1={
    obj:[
        {
            "top": -1, "left": -1, "bottom": 1, "right": -1, "value": "M","idx":0, "initX":50,"initY":50
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "A","idx":1
        }, 
		
		{
            "top": -1, "left": -1, "bottom":-1, "right": 3, "value": "T","idx":2, "initX":250,"initY":300
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "A","idx":3
        }, 
		
		{
            "top": -1, "left": -1, "bottom":-1, "right": 5, "value": "U","idx":4, "initX":50,"initY":450
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "I","idx":5
        }, 
		
		{
            "top": -1, "left": -1, "bottom":7, "right": -1, "value": "N","idx":6, "initX":200,"initY":50
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "G","idx":7
        }, 
		
		{
            "top": -1, "left": -1, "bottom":9, "right": -1, "value": "M","idx":8, "initX":100,"initY":200
        }, 
		{
            "top": -1, "left": -1, "bottom": 10, "right": -1, "value": "I","idx":9
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "E","idx":10
        }, 
    ],
    answer:[
        {"isSolved":false,"value":[0,1,2],"text":"MAT"},
		{"isSolved":false,"value":[8,4,5],"text":"MUI"},
		{"isSolved":false,"value":[2,3,9],"text":"TAI"},
		{"isSolved":false,"value":[8,9,10,6,7],"text":"MIENG"},
		
    ]

}
