var level1={
    obj:[
        {
            "top": -1, "left": -1, "bottom": 1, "right": -1, "value": "C","idx":0, "initX":50,"initY":50
        }, 
        {
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "A","idx":1
        }, 
        
        {
            "top": -1, "left": -1, "bottom": -1, "right": 3, "value": "T","idx":2, "initX":200,"initY":450
        }, 
        {
            "top": -1, "left": -1, "bottom": -1, "right": 4, "value": "H","idx":3
        }, 
        {
            "top": -1, "left": -1, "bottom": -1, "right": 5, "value": "U","idx":4
        }, 
        {
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "Y","idx":5
        }, 
        
        {
            "top": -1, "left": -1, "bottom": -1, "right": 7, "value": "E","idx":6, "initX":250,"initY":150
        }, 
        {
            "top": -1, "left": -1, "bottom": 8, "right": -1, "value": "N","idx":7
        }, 
		 {
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "G","idx":8
        }, 
        
        {
            "top": -1, "left": -1, "bottom": -1, "right": 10, "value": "I","idx":9, "initX":150,"initY":550
        }, 
        {
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "O","idx":10
        }, 
        
        
        {
            "top": -1, "left": -1, "bottom": 12, "right": -1, "value": "S","idx":11, "initX":50,"initY":300
        }, 
        {
            "top": -1, "left": -1, "bottom": 13, "right": -1, "value": "O","idx":12
        }, 
       
    ],
    answer:[
        {"isSolved":false,"value":[0,1,2],"text":"CAT"},
        {"isSolved":false,"value":[2,3,4,5,6,7],"text":"THUYEN"},
        {"isSolved":false,"value":[8,9,10],"text":"GIO"},
        {"isSolved":false,"value":[11,12,7,8],"text":"SONG"},
    ]
    ,clue:"Bãi bi?n"
}