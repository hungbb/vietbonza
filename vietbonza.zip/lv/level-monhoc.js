var level1={
    obj:[
        {
            "top": 1, "left": -1, "bottom": -1, "right": -1, "value": "E","idx":0, "initX":50,"initY":150
        }, 
		{
            "top": 2, "left": -1, "bottom": -1, "right": -1, "value": "H","idx":1
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 3, "value": "T","idx":2
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "O","idx":3
        }, 
		
		{
            "top": -1, "left": -1, "bottom": 5, "right": -1, "value": "D","idx":4, "initX":200,"initY":450
        }, 
		{
            "top": -1, "left": -1, "bottom": 6, "right": -1, "value": "U","idx":5
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "C","idx":6
        }, 
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 8, "value": "A","idx":7, "initX":250,"initY":150
        }, 
		{
            "top": 9, "left": -1, "bottom": 10, "right": -1, "value": "N","idx":8
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "E","idx":9
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "G","idx":10
        }, 
		
		{
            "top": -1, "left": -1, "bottom": 12, "right": -1, "value": "V","idx":11, "initX":100,"initY":250
        }, 
		{
            "top": -1, "left": -1, "bottom": 13, "right": -1, "value": "I","idx":12
        }, 
		{
            "top": -1, "left": -1, "bottom": 14, "right": -1, "value": "E","idx":13
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "T","idx":14
        }, 
		
		{
            "top": 16, "left": -1, "bottom": -1, "right": -1, "value": "I","idx":15, "initX":400,"initY":300
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 17, "value": "T","idx":16
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 18, "value": "H","idx":17
        }, 
		{
            "top": 19, "left": -1, "bottom": -1, "right": -1, "value": "U","idx":18
        }, 
		{
            "top": 20, "left": -1, "bottom": -1, "right": -1, "value": "H","idx":19
        }, 
		{
            "top": 21, "left": -1, "bottom": -1, "right": -1, "value": "T","idx":20
        }, 
		{
            "top": 22, "left": -1, "bottom": -1, "right": -1, "value": "I","idx":21
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "M","idx":22
        }, 
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 24, "value": "C","idx":23, "initX":300,"initY":500
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 25, "value": "O","idx":24
        }, 
		{
            "top": 27, "left": -1, "bottom": -1, "right": 26, "value": "N","idx":25
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "G","idx":26
        }, 
		{
            "top": 28, "left": -1, "bottom": -1, "right": -1, "value": "M","idx":27
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "A","idx":28
        }, 
		
		{
            "top": -1, "left": -1, "bottom": 30, "right": -1, "value": "H","idx":29, "initX":250,"initY":300
        }, 
		{
            "top": -1, "left": -1, "bottom": 31, "right": -1, "value": "A","idx":30
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "C","idx":31
        }, 
		
		{
            "top": -1, "left": -1, "bottom": 33, "right": -1, "value": "Y","idx":32, "initX":50,"initY":450
        }, 
		{
            "top": -1, "left": -1, "bottom": 34, "right": -1, "value": "A","idx":33
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "T","idx":34
        }, 
    ],
    answer:[
        {"isSolved":false,"value":[2,1,0,4,5,6],"text":"THEDUC"},
		{"isSolved":false,"value":[2,3,7,8],"text":"TOAN"},
		{"isSolved":false,"value":[16,15,9,8,10,11,12,13,14],"text":"TIENGVIET"},
		{"isSolved":false,"value":[16,17,18,23,24,25,26],"text":"THUCONG"},
		{"isSolved":false,"value":[22,21,20,19,18,32,33,34],"text":"MITHUAT"},
		{"isSolved":false,"value":[28,27,25,29,30,31],"text":"AMNHAC"},
    ]

}
