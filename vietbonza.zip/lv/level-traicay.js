var level1={
    obj:[
        {
            "top": -1, "left": -1, "bottom": 1, "right": -1, "value": "X","idx":0, "initX":50,"initY":50
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "O","idx":1
		},
		
		{
            "top": -1, "left": -1, "bottom": 3, "right": -1, "value": "A","idx":2, "initX":200,"initY":400
        }, 	
		{
            "top": -1, "left": -1, "bottom": -1, "right": 4, "value": "I","idx":3
		},
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "T","idx":4
		},
		
		{
            "top": -1, "left": -1, "bottom": 6, "right": -1, "value": "M","idx":5, "initX":100,"initY":150
        }, 	
		{
            "top": -1, "left": -1, "bottom": 7, "right": -1, "value": "A","idx":6
		},
		{
            "top": -1, "left": -1, "bottom": 8, "right": -1, "value": "N","idx":7
		},
		{
            "top": -1, "left": -1, "bottom": 9, "right": -1, "value": "G","idx":8
		},
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "C","idx":9
		},
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 11, "value": "A","idx":10, "initX":200,"initY":250
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "M","idx":11
		},
		
		{
            "top": -1, "left": -1, "bottom": 13, "right": -1, "value": "A","idx":12, "initX":0,"initY":450
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "O","idx":13
		},
		
		{
            "top": -1, "left": -1, "bottom": 15, "right": -1, "value": "A","idx":14, "initX":300,"initY":0
        }, 
		{
            "top": -1, "left": 16, "bottom": -1, "right": -1, "value": "U","idx":15
		},
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "B","idx":16
		},
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 18, "value": "O","idx":17, "initX":200,"initY":150
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "I","idx":18
		},
    ],
    answer:[
        {"isSolved":false,"value":[0,1,2,3],"text":"XOAI"},
		{"isSolved":false,"value":[4,12,13],"text":"TAO"},
		{"isSolved":false,"value":[5,3,4],"text":"MIT"},
		{"isSolved":false,"value":[9,10,11],"text":"CAM"},
		{"isSolved":false,"value":[5,6,7,8,9,14,15],"text":"MANGCAU"},
		{"isSolved":false,"value":[16,15,17,18],"text":"BUOI"},
    ]

}
