var level1={
    obj:[
        {
            "top": -1, "left": -1, "bottom": -1, "right": 1, "value": "N","idx":0, "initX":50,"initY":50
        }, 
		{
			"top": -1, "left": -1, "bottom": 4, "right": 2, "value": "H","idx":1
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": 3, "value": "A","idx":2
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "N","idx":3
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "D","idx":4
		},
		
		{
            "top": -1, "left": -1, "bottom": 6, "right": -1, "value": "B","idx":5, "initX":50,"initY":450
        },
		{
			"top": -1, "left": 8, "bottom": 7, "right": -1, "value": "A","idx":6
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "C","idx":7
		},	
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "N","idx":8
		},

		{
            "top": -1, "left": -1, "bottom": -1, "right": 10, "value": "G","idx":9, "initX":250,"initY":400
        },
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "O","idx":10
		},
		
		{
            "top": -1, "left": -1, "bottom": 12, "right": -1, "value": "A","idx":11, "initX":250,"initY":200
        },
		{
			"top": -1, "left": -1, "bottom": 13, "right": -1, "value": "N","idx":12
		},
		{
			"top": -1, "left": 14, "bottom": -1, "right": -1, "value": "G","idx":13
		},
		{
			"top": -1, "left": 15, "bottom": -1, "right": -1, "value": "N","idx":14
		},
		{
			"top": -1, "left": 16, "bottom": -1, "right": -1, "value": "O","idx":15
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "D","idx":16
		},
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 18, "value": "C","idx":17, "initX":50,"initY":200
        },
		{
			"top": -1, "left": -1, "bottom": -1, "right": 19, "value": "O","idx":18
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "C","idx":19
		},
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 21, "value": "M","idx":20, "initX":150,"initY":500
        },
		{
			"top": -1, "left": -1, "bottom": -1, "right": 22, "value": "H","idx":21
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": 23, "value": "A","idx":22
		},
		{
			"top": -1, "left": -1, "bottom": -1, "right": -1, "value": "N","idx":23
		},
    ],
    answer:[
        {"isSolved":false,"value":[5,6,7,1,4,11,12,13],"text":"BACHDANG"},
		{"isSolved":false,"value":[8,6,20,21,22,23],"text":"NAMHAN"},
		{"isSolved":false,"value":[0,1,2,3,9,10],"text":"NHANGO"},
		 {"isSolved":false,"value":[16,15,14,13,17,18,19],"text":"DONGCOC"},
		
    ]

}
