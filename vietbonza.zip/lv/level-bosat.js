var level1={
    obj:[
        {
            "top": -1, "left": -1, "bottom": 1, "right": -1, "value": "C","idx":0, "initX":150,"initY":100
        }, 
		{
            "top": -1, "left": 2, "bottom": -1, "right": -1, "value": "A","idx":1
        }, 
		{
            "top": -1, "left": 3, "bottom": -1, "right": -1, "value": "H","idx":2
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "T","idx":3
        }, 
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 5, "value": "N","idx":4, "initX":200,"initY":450
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 6, "value": "L","idx":5
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 7, "value": "A","idx":6
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "N","idx":7
        }, 
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 9, "value": "K","idx":8, "initX":250,"initY":150
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 10, "value": "H","idx":9
        }, 
		{
            "top": 13, "left": -1, "bottom": -1, "right": 11, "value": "U","idx":10
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 12, "value": "N","idx":11
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "G","idx":12
        }, 
		{
            "top": 14, "left": -1, "bottom": -1, "right": -1, "value": "A","idx":13
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "X","idx":14
        }, 
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 16, "value": "L","idx":15, "initX":0,"initY":300
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 17, "value": "O","idx":16
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": 18, "value": "N","idx":17
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "G","idx":18
        }, 
		
		{
            "top": -1, "left": -1, "bottom": 20, "right": -1, "value": "R","idx":19, "initX":50,"initY":450
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "A","idx":20
        }, 
		
		{
            "top": -1, "left": -1, "bottom": -1, "right": 22, "value": "U","idx":21, "initX":250,"initY":300
        }, 
		{
            "top": -1, "left": -1, "bottom": -1, "right": -1, "value": "A","idx":22
        }, 
		
		
		
    ],
    answer:[
        {"isSolved":false,"value":[0,1,14,13,10],"text":"CAXAU"},
		{"isSolved":false,"value":[3,2,1,4,5,6,7],"text":"THANLAN"},
		{"isSolved":false,"value":[8,9,10,11,12,15,16,17,18],"text":"KHUNGLONG"},
		{"isSolved":false,"value":[19,20,17],"text":"RAN"},
		{"isSolved":false,"value":[19,21,22],"text":"RUA"},
    ]

}
